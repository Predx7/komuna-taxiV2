export default {
  root: './',
};
