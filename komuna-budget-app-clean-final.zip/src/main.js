import { initRouter } from './router.js';
import './style.css';

document.addEventListener('DOMContentLoaded', () => {
  initRouter();
});
